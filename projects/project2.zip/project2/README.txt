Jacob Tingler

Title -- Hangman

This is a response web app that uses an on screen keyboard 
to take in user input to guess a disney movie. It saves the score of the user
to local storage and displays it the scores on a highscores list.

Link to Project --- https://jacobtingler.github.io/jacobtingler/projects/project2/project2.html